    <?php 

/*

        Page avantage.php

        Vente des avantages de l'adhésion .


*/
        ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
                    

                     <title>Avantage</title>
                     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                     <meta name="language" content="fr" />
                     <link rel="stylesheet"  type="text/css" href="style/style.css" />
             
                </head>

<body>

                <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
            </div>
                <div class="menu">
                
                      <ul>
                           <li> <a href="index.php">Accueil</a></li>
                           
                        </ul>

                
               
            </div>

                            <div id="banner2">
                            </div>

        <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> 
</body>

 <?php
                include('/includes/bas_de_page.php');
          ?>