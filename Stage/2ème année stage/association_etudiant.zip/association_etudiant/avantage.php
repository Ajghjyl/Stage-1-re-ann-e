<?php 

    /*

            Page avantage.php

            Vente les avantages de l'adhésion .


    */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
                    

                     <title>Avantage</title>
                     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                     <meta name="language" content="fr" />
                     <link rel="stylesheet"  type="text/css" href="style/style.css" />
             
                </head>

        <body>

                        <div id="banner1">
                                <p>ASSOSSIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>

                        <div class="menu">

                              <ul>
                                   <li> <a href="index.php">Accueil</a></li> 
                              </ul>
                        </div>

                        <div id="banner2">
                        </div>
                        <!--Contenu-->
                        <h1><a class="rejoins" href="membres/inscription.php">Rejoins-Nous!</a></h1>
                        <h3>Une association des étudiants sa sert à...</h3>
                        <p>+A mettre un plus dans son CV.</p>
                        <p>+Participer des activités durant toute l'année.</p>
                        <p>+Avoir une expérience plus enrichissante au sein de l'établissement scolaire.</p>
                        <p>+Créer des projets en collectifs.</p>
                        <p>+D'appartenir à un groupe.</p>
                        <p>+Ce créer un réseau de contact pour plus tard.</p>
                        <p>+Des compétences tels que la gestion des projets et le sens du relationnel.</p>

                <br><br><br><br><br><br><br><br>

 <?php
                include('includes/bas_de_page.php');
          ?>