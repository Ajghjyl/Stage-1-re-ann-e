<?php 

/*

        


*/
       
    session_start();
    if (!isset($_SESSION['membre']))
    {
        header ('Location: profil.php');
        exit();
    }
    
    
                include('../includes/BDD.php');
               
          ?>

          <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>
              <div class="menu">
                          <ul>
                                <li> <a href="profil.php">Mon compte</a> </li> 
                                <li> <a href="traitement/deconnexion.php">Se déconnecter</a> </li>
                                
                            
                          </ul>
            <h1>Profil de <?= $_SESSION['membre']['pseudo'] ?></h1><br>
            

             <div id="banner2">
                                
        </div>


       <?php include('../includes/navigateur.php'); ?>


            <form action="traitement/publishQuestionAction.php" method="post" name="Publication">
            <fieldset>
                <legend>Question</legend>

            <div class="mb-3">
                <label for="title" class="form-label">Titre :</label> 
                <input type="text" class="form-control" name="title" id="title"  /> 
            </div>

            <div class="mb-3">  
                <label for="description" class="form-label">Description :</label>
                <textarea class="form-control" name="description"></textarea>
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Contenu</label> 
                <textarea  class="form-control" name="content" id="content" > </textarea>
            </div>

            </fieldset>
                    <div class="center"><input type="submit" value="Publier" /></div>
                    <?php 
                     if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       } ?>
                      
            </form>
            
    </body>
</html>
 <?php
                include('../includes/bas_de_page.php');
          ?>