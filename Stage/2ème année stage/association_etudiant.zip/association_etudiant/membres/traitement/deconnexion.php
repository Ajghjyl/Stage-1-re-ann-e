<?php
/*

Page deconnexion.php

Permet de se déconnecter du site.

*/

session_start();
       if (!$_SESSION["membre"]) {
              header("Location: index.php");
       }
       if ($_SESSION["admin"]) {
              header("Location: ../../admin/index.php");
       }
       
unset($_SESSION["membre"]); // PAS DE DESTROY OU VOUS RISQUEZ DE DETRUIRE TOUTE LES SESSIONS ON VEUT JUSTE RETIRER LE CONTENU DANS UNE SESSION SPECIFIQUE

header("Location: ../connexion.php")


?>