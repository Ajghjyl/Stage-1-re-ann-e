<?php 
		session_start();
		require_once("../../includes/BDD.php");

		if (!empty($_POST)) 
              {
                     
                      
                        // Le formulaire a été envoyé
                        //On vérifie que TOUS les champs requis sont remplis et les conditions requises
                         if(
                                isset( $_POST['title'] ,$_POST['description'], $_POST['content'] )
                                && !empty($_POST['title'])&& !empty($_POST['description'])&& !empty($_POST['content']) 
                           )
                         {
                         		$title = htmlentities($_POST['title'], ENT_QUOTES, "UTF-8");
                         		$description = nl2brhtmlentities($_POST['description'], ENT_QUOTES, "UTF-8");
                         		$content = nl2brhtmlentities($_POST['content'], ENT_QUOTES, "UTF-8");
                         		$date = date("F j M, Y, g:i a");

                         		$author_id = $_SESSION['membre']['id'];
                         		$author_pseudo = $_SESSION['membre']['pseudo'];

                         		$sql="INSERT INTO questions (titre, description, contenu, date, id_auteur, pseudo_auteur)
                                   VALUES ('$title', '$description', '$content', 'date', 'author_id','author_pseudo')";

                                //On prépare la requête
                                $query= $bdd->prepare($sql);

                                //On exécute la requête
                                if(!$query->execute())
                                {
                                    die("Problème avec l'exécusion");
                                }

                                 
                         }
                         else
                         {
                         	// Envoie un message d'erreur          
                                $_SESSION['erreurLogin'] = "Le formulaire est incomplet.";
                                header("Location: ../publish_question.php");
                         }          
              }
              else
              {
        	     header("Location:  publish_question.php");
                   exit;
              }
?>