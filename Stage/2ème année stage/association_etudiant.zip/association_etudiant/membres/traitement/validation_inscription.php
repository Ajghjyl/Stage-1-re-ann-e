<?php
    /*

    Permet de valider son inscription.

    */

    
    header('Content-type: text/html; charset=utf-8');
    include_once('../../includes/config.php');
   

   /********Actualisation de la session...**********/

    include('../includes/fonctions.php');
   
    
 session_start();
   

    require_once("../../includes/BDD.php");

    /********Fin actualisation de session...**********/

 
        /**********************************On vérifie si le formulaire a été envoyé**********************************/
           
  
                if (!empty($_POST)) 
                {
                     
                      
                        // Le formulaire a été envoyé
                        //On vérifie que TOUS les champs requis sont remplis et les conditions requises
                         if(
                                isset($_POST['pseudo'] ,$_POST['mdp1'], $_POST['mdp2'], $_POST['email']) 
                                && !empty($_POST['pseudo'])&& !empty($_POST['mdp1'])&& !empty($_POST['mdp2'])&& !empty($_POST['email'])
                           )
                            {
                                //Le formulaire est complet
                                //On récupère les données en les protégeants
                                
                                
                                //Les conditions requises
                             
                                //Pseudo
                                if(     isset ($_POST['pseudo']))  
                                {
                                        $pseudo = htmlentities($_POST['pseudo'], ENT_QUOTES, "UTF-8");
                                        $pseudo_result = checkpseudo($pseudo);

                                        if($pseudo_result == 'tooshort')
                                        {
                                                        // Envoie un message d'erreur          
                                                             
                                                        $_SESSION['erreurLogin'] = "Le pseudo est trops court.";
                                                        header("Location: ../inscription.php");    
                                                
                                        }
                                        
                                        else if($pseudo_result == 'toolong')
                                        {
                                                       // Envoie un message d'erreur 
                                                                         
                                                             
                                                        $_SESSION['erreurLogin'] = "Le pseudo est trops long.";
                                                 header("Location: ../inscription.php");
                                        }
                                        
                                        else if($pseudo_result == 'exists')
                                        {
                                                // Envoie un message d'erreur          
                                                             
                                                $_SESSION['erreurLogin'] = "Ce pseudo est utilisé par quelqu'un d'autre.";
                                                 header("Location: ../inscription.php");
                                                
                                        }
                                               
                                        else if($pseudo_result == 'ok')
                                        {
                                                $_SESSION['pseudo_info'] = '';
                                                $_SESSION['form_pseudo'] = $pseudo_result;
                                        }



                                }

                               
                                //email
                                if(isset($_POST['email']))
                                {
                                        $email = htmlentities($_POST['email'], ENT_QUOTES, "UTF-8");

                                        
                                                 $email_result = checkmail($email);
                                                if($email_result == 'isnt')
                                                {
                                                        // Envoie un message d'erreur          
                                                                    
                                                                $_SESSION['erreurLogin'] = "Ce mail n'en est pas un.";
                                                                header("Location: ../inscription.php");
                                                        
                                                }
                                                
                                                else if($email_result == 'exists')
                                                {
                                                       // Envoie un message d'erreur          
                                                                     
                                                              $_SESSION['erreurLogin'] = "Cette email est utilisé par quelqu'un d'autre.";
                                                                header("Location: ../inscription.php");
                                                       
                                                }
                                                        
                                                else if($email_result == 'ok')
                                                {
                                                        $_SESSION['mail_info'] = '';
                                                        $_SESSION['form_mail'] = $email;
                                                        $checkEmail = true;
                                                        
                                                }
                                       
                                       
                                        
                                        
                                }




                                //Mot de passe 
                                if(isset($_POST['mdp1']))
                                {
                                        $mdp = htmlentities($_POST['mdp1'], ENT_QUOTES, "UTF-8");
                                        $mdp_result = checkmdp($mdp);

                                        if($mdp_result == 'tooshort')
                                        {
                                                  
                                                $_SESSION['erreurLogin'] = "Le mot de passe est trops court.";
                                                 header("Location: ../inscription.php");
                                               
                                               
                                        }
                                        
                                        else if($mdp_result == 'toolong')
                                        {
                                                
                                                $_SESSION['erreurLogin'] = "Le mot de passe est trops long.";
                                                header("Location: ../inscription.php");
                                                
                                        }
                                        
                                        else if($mdp_result == 'nofigure')
                                        {
                                              
                                                $_SESSION['erreurLogin'] = "Le mot de passe doit contenir au moins une majuscule et un chiffre.";
                                                 header("Location: ../inscription.php");
                                                
                                        }
                                                
                                        else if($mdp_result == 'noupcap')
                                        {
                                                 
                                                $_SESSION['erreurLogin'] = "Le mot de passe doit contenir au moins une majuscule et un chiffre.";
                                                header("Location: ../inscription.php");
                                                
                                        }
                                                
                                        else if($mdp_result == 'ok')
                                        {
                                                $_SESSION['mdp_info'] = '';
                                                $_SESSION['form_mdp'] = $mdp;
                                        }
                                        
                                       
                                }

                             




                                //Mot de passe vérification
                                if(isset($_POST['mdp2']) && isset($_POST['mdp1']))
                                {
                                        $mdp2 = htmlentities($_POST['mdp2'], ENT_QUOTES, "UTF-8");
                                        $mdp1 = htmlentities($_POST['mdp1'], ENT_QUOTES, "UTF-8");
                                        $mdp_verif_result = checkmdpS($mdp2,$mdp1);

                                        if($mdp_verif_result == 'different')
                                        {
                                                
                                                $_SESSION['erreurLogin'] = "Le mot de passe de vérification est différent.";
                                                 header("Location: ../inscription.php");
                                                
                                                if(isset($_SESSION['form_mdp'])) unset($_SESSION['mdp2']);
                                        }
                                        
                                       
                                }



                                // On enregistre en BDD
                               
                                

                                $sql="INSERT INTO membres (membre_pseudo, membre_mdp, membre_mail, membre_type)
                                VALUES ('$pseudo', '$mdp1', '$email', 'user')";

                                 
                                //On prépare la requête
                                $query= $bdd->prepare($sql);


                                //on connecte les variable php a leur paramètre SQL
                                $query->bindValue(":pseudo",$pseudo, PDO::PARAM_STR);
                                $query->bindValue(":email",$email, PDO::PARAM_STR);
                                $type = 'user';
                                 
                                //On exécute la requête
                                if(!$query->execute())
                                {
                                    die("Problème avec l'exécusion");
                                }



                                $membre_id= mysqli_insert_id();

                                
                                //On connectera l'utilisateur
                                //on va ouvrir la session

                                
                                //On stocke dans $_SESSION les infos de l'utilisateurs
                                $_SESSION['membre'] = 
                                [
                                        "id" => $membre_id,
                                        "pseudo" => $pseudo,
                                        "email" => $email,
                                        "type" => $type
                
                                ];

                                //On le redige vers la page de profil'
                                header("Location: profil.php");
                
                           } 
                           else
                           {     
                                // Envoie un message d'erreur          
                                $_SESSION['erreurLogin'] = "Le formulaire est incomplet.";
                                header("Location: ../inscription.php");          
                           }
                 
                }
                 else
              {
                 
                
                    header("Location:  ../inscription.php");
                    exit;
          
                
              }
       
?>                       