<?php
       /*

       Page connexion.php

       Permet de se connecter au site.




       Liste des informations/erreurs :
       --------------------------
       Membre qui essaie de se connecter alors qu'il l'est déjà
       Vous êtes bien connecté
       Erreur de mot de passe
       Erreur de pseudo doublon (normalement impossible)
       Pseudo inconnu
       --------------------------
       */

       
       header('Content-type: text/html; charset=utf-8');
       include('../../includes/config.php');

       /********Actualisation de la session...**********/

       include('../../includes/fonctions.php');
       
       session_start();

 
        

       /********Fin actualisation de session...**********/

  
       //On Vérifie que le visiteur a bien envoyer le formulaire.

              
              if (!empty($_POST))  
              {
                     
                     // Le formulaire a été envoyé
                     //On vérifie que TOUS les champs requis sont remplis
                     
                     
                     if(isset($_POST['pseudo'], $_POST['mdp1'] )&& !empty($_POST['pseudo']) && !empty($_POST['mdp1']))  
                        
                     {
                            
                             
                            require_once("../../includes/BDD.php");
                    
                            $Pseudo = htmlentities($_POST['pseudo'], ENT_QUOTES, "UTF-8"); 
                            $MotDePasse = htmlentities($_POST['mdp1'], ENT_QUOTES, "UTF-8");

                            $sql = "SELECT * FROM membres WHERE membre_pseudo= '".$Pseudo."' AND membre_mdp = '".$MotDePasse."' ";


                            $query = $bdd->prepare($sql);

                            $query-> bindValue(":pseudo", $_POST['pseudo'], PDO::PARAM_STR);



                            if(!$query->execute())
                            {
                                   die("Problème avec l'exécusion");
                            }


                            $user = $query->fetch();

                            //Est-ce que les données sont dans cette table?
                            $row = $query->rowCount();

                            if ($row== 1) 
                            {      
                                    

                                    if ($user["membre_mdp"] === $MotDePasse) 
                                    {  
                                          if ($user['membre_type'] == "admin") 
                                          {       
                                                 $_SESSION['admin'] = 
                                                        [
                                                               "id" =>$user['membre_id'],
                                                               "pseudo" =>$user['membre_pseudo'],
                                                               "email" =>$user['membre_mail'],
                                                               "type" =>$user['membre_type']
                                                        ];
                                                 header("Location: ../../admin/index.php");
                                          }
                                          else
                                          {
                                                 $_SESSION['membre'] = 
                                          [
                                                 "id" =>$user['membre_id'],
                                                 "pseudo" =>$user['membre_pseudo'],
                                                 "email" =>$user['membre_mail'],
                                                 "type" =>$user['membre_type']
                                          ];
                                                    
                                          header("Location: ../profil.php");

                                          }
                                          

                                    }
                                    else
                                    {
                                          
                                          $_SESSION['erreurLogin'] = "Le pseudo et/ou le mot de passe est incorrect";
                                          header("Location: ../connexion.php");
                                    }
               
                                        
                            }
                            else
                            {     
                                   $_SESSION['erreurLogin'] = "Le pseudo et/ou le mot de passe est incorrect ";
                                   header("Location: ../connexion.php");
                            } 

                            

                            
                            
                     }
                     else
                     {      
                            $_SESSION['erreurLogin'] = "Le formulaire est incomplet";
                            header("Location: ../connexion.php");                           
                                                 
                     }   
                   
              }
              else
              {      
                     header("Location: ../connexion.php");
                     exit;
              }

?>

                           