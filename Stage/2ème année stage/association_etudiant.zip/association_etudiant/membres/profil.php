<?php
        /*

        Page PROFIL.php

        Affichage de profil.


        */
        
        session_start();

		if (!isset($_SESSION['membre'])) 
		{
	        header("Location:  connexion.php");
	        exit;
	        
	    }
        header('Content-type: text/html; charset=utf-8');
        include('../includes/config.php');

        /********Actualisation de la session...**********/
        //Les fonctions

        include('../includes/fonctions.php');


        /********Fin actualisation de session...**********/

?>




 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

        <head>

             <title>Profil</title>
             <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
             <meta name="language" content="fr" />
             <link rel="stylesheet"  type="text/css" href="../style/style.css" />
             
        </head>

<!---->
<!---->

       <body>
                    <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>
            
           
                
                      <div class="menu">
                          <ul>
                                <li> <a href="compte.php">Mon compte</a> </li> 
                                <li> <a href="traitement/deconnexion.php">Se déconnecter</a> </li>
                                <li> <a href="accueil.php">Discusion</a> </li>

                            
                          </ul>
                       </div>
                
                      
        <div id="banner2">
                                
        </div>


            <br><br>
           
                                
         

        	<h1>Profil de <?= $_SESSION['membre']["pseudo"] ?></h1>
			<p>Pseudo : <?= $_SESSION['membre']["pseudo"] ?></p>
			<p>Email : <?= $_SESSION['membre']["email"] ?></p>
	</body>

			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php 
	include("../includes/bas_de_page.php");
?>



