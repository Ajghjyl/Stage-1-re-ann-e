 <?php 
 session_start();

 
            if (isset($_SESSION['membre']))
            {
                header ('Location: ../membres/profil.php');
                exit();
            }
            if (isset($_SESSION['admin'])) {
                 header ('Location: ../admin/index.php');
                exit();
            }

 include ('../includes/haut_de_page.php');
?>
 <h1>Profil de <?= $_SESSION['membre']['pseudo'] ?></h1> <br>
            
<?php include('../includes/navigateur.php'); ?>