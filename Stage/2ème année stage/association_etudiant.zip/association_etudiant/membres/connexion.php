<?php
    /*

    Page connexion.php

    Permet de se connecter.

    */

    
    header('Content-type: text/html; charset=utf-8');

    include_once('../includes/config.php');


      
        /********Actualisation de la session...**********/
        //Les fonctions
        include('../includes/fonctions.php');

       
        
            session_start();
           

            if (isset($_SESSION['membre']))
            {
                header ('Location: ../membres/profil.php');
                exit();
            }
            if (isset($_SESSION['admin'])) {
                 header ('Location: ../admin/index.php');
                exit();
            }

        /********Fin actualisation de session...**********/
   include("../includes/haut_de_page.php")
?>




                <form action="traitement/validation_connexion.php" method="post" name="Connexion">
                <fieldset>
                <legend>Connexion</legend>

                <label for="pseudo" class="float">Pseudo :</label> 
                <input type="text" name="pseudo" id="pseudo" size="30" /> 
                <br>

                <label for="mdp1" class="float">Mot de passe :</label>
                <input type="password" name="mdp1" id="mdp1" size="30" />
                <br/>

            </fieldset>
                    <div class="center"><input type="submit" value="Connexion" /></div>
            </form>
              <?php 
               
                       if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       }
                       
              ?>
                        
                        <h1>Options</h1>
                        <p><a href="inscription.php">Je ne suis pas inscrit !</a><br/>
                        <a href="compte.php?action=reset">J'ai oublié mon mot de passe !</a>
                        </p>

                       
      <!--bas-->
     
      <br><br><br><br><br><br><br><br><br><br><br>
      
                <div id="footer">
                        <p>Pied de page</p>
                </div>  
         </body>
 </html>