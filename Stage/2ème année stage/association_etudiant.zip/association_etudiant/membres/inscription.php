<?php
    /*

    Page inscription.php

    Permet de s'inscrire.
 
    */

    
     
    header('Content-type: text/html; charset=utf-8');
    include_once('../includes/config.php');
     
        /********Actualisation de la session...**********/

        include('../includes/fonctions.php');
     


        actualiser_session();
		session_start();
            if (isset($_SESSION['membre']))
            {
                header ('Location: ../membres/profil.php');
                exit();
            }
        /********Fin actualisation de session...**********/
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
	            <?php
	                /**********Vérification du titre...*************/
	               $titre = 'Inscription';

	                if(isset($titre) && trim($titre) != '')
	                $titre = $titre.' : '.TITRESITE;
	    
	                else
	                        $titre = TITRESITE;
	                         /*
	                                Rien de bien particulier ici, à part le titre, le menu et la bannière.Elle contiendra 
	                                le code minimal HTML nécessaire de n'importe qu'elle site Internet.

	                        Pour le titre (dans la balise <title> ), on vérifie simplement que la variable existe : 
	                        si oui, on l'affiche.*/
	    
	                /***********Fin vérification titre...************/
	             ?>

	             <title><?php echo $titre; ?></title>
	             <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	             <meta name="language" content="fr" />
	             <link rel="stylesheet"  type="text/css" href="../style/style.css" />
             
        	</head>
        <body>

        	<div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
            </div>
                <div class="menu">
                	<ul>
                        <li> <a href="../index.php">Accueil</a></li> 
                    </ul> 
            </div>

            <div id="banner2">
            </div>
			

			<h1>Formulaire d'inscription</h1>
			<p>Bienvenue sur la page d'inscription!<br/>
			Merci de remplir ces champs pour continuer.</p>

			<form action="traitement/validation_inscription.php" method="post" name="Inscription">
			<fieldset>
				<legend>Identifiants</legend>

				<label for="pseudo" class="float">Pseudo :</label> 
	        	<input type="text" name="pseudo" id="pseudo" size="30" /> 
	        	<em>(compris entre 5 et 32 caractères)</em><br />

	        	
				<label for="mdp1" class="float">Mot de passe :</label>
	            <input type="password" name="mdp1" id="mdp1" size="30" /> 
	            <em>(compris entre 8 et 50 caractères)</em><br />


				<label for="mdp2" class="float">Mot de passe (vérification) :</label> 
	            <input type="password" name="mdp2" id="mdp2" size="30" /><br />


				<label for="email" class="float">Email :</label> 
	            <input type="text" name="email" id="email" size="30" /> <br />

			</fieldset>
	                <div class="center"><input type="submit" value="Inscription" /></div>
	                <?php 
	                 if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       } ?>
	                  
			</form>
	        
	    </br></br></br></br></br></br></br></br></br><br>
        				<!--bas-->

  				<div id="footer">
                        <p>Pied de page</p>
                </div>	
         </body>
 </html>