<?php
    /*
    Rien de bien particulier ici, à part le titre, le menu et la bannière.Elle contiendra 
    le code minimal HTML nécessaire de n'importe qu'elle site Internet.

    
*/
    require_once __DIR__ . "/../includes/config.php";

?>



 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
              
            
            

                <?php
                    /**********Vérification du titre...*************/
                   

                    if(isset($titre) && trim($titre) != '')
                    $titre = $titre.' : '.TITRESITE;
        
                    else
                            $titre = TITRESITE;
                             /*
                                   

                            Pour le titre (dans la balise <title> ), on vérifie simplement que la variable existe : 
                            si oui, on l'affiche.*/
        
                    /***********Fin vérification titre...************/
                 ?>

             <title><?php echo $titre; ?></title>
             <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
             <meta name="language" content="fr" />
             <link rel="stylesheet"  type="text/css" href="style/style.css" />
             
        </head>

<!---->
<!---->

       <body>
                    <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>
            
           

                <?php
                        if (isset($_SESSION["admin"])) 
                        { ?>
                             <div class="menu">
                          <ul>
                                <li> <a href="../admin/index.php">Mon compte</a> </li> 
                                <li> <a href="../admin/deconnexion.php">Se déconnecter</a> </li>
                                
                            
                          </ul>
                      <?php  }
                        else
                        {
                        if(isset($_SESSION["membre"]))
                        {
                ?>
                      <div class="menu">
                          <ul>
                                <li> <a href="/profil.php">Mon compte</a> </li> 
                                <li> <a href="/deconnexion.php">Se déconnecter</a> </li>
                                
                            
                          </ul>
                <?php
                        }
                        
                        else
                        {
                ?>
                        <div class="menu">
                            <ul>
                                <li> <a href="membres/inscription.php">Inscription</a> </li>
                                <li> <a href="membres/connexion.php">Connexion</a> </li>
                                

                            </ul>
                        </div>
                <?php 
                        }
                    }
                    
                  ?>
                      
        <div id="banner2">
                                
        </div>


                           
                                
         