<?php
			//Définition des constantes de connexion à la base de données
			define("DBHOST", "localhost");
			define("DBUSER", "root");
			define("DBPASSWD", "root");
			define("DBNAME", "association_etudiant");
	    	
				//DSN de connexion
	    		$dsn = "mysql:dbname=".DBNAME.";host=".DBHOST;

	    		//option de PDO.
	    		$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

	    		//Connexion à la base de données
		    	try
		    	{	
		    		//On instancie PDO
		    		
		        	$bdd = new PDO($dsn, DBUSER, DBPASSWD, $pdo_options);
	



		        	//On s'assure d'envoyer les données en UTF8
		        	$bdd->exec("SET NAMES utf8");

	

        	

		    	}
		    	//Tester si problème de connexion à la BDD.
		   	 	catch(PDOException $e)
		    		{
		        		die("Erreur de connexion à la BDD: ".$e->getMessage() );
		    		}

		    		
?>