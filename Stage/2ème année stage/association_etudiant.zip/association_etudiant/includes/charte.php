<?php

 echo "Le formulaire est complet";
                                  
/*

Page charte.php

Contient la charte.

*/
?>
					<div id="charte">
						<h1>La charte du site :</h1>
						<p>Ce site contient un espace membres, un forum, un système de news ainsi que d'autres modules.<br/>
						En vous inscrivant, vous reconnaissez avoir pris connaissance de cette charte et l'avoir acceptée.
						</p><br/>
						
						<div class="chartecat">Règlement Général du site</div><br/>

						<p>Ce site et toutes ses pages sont soummis à la loi française, par conséquent, il est interdit
						d'y tenir des propos ou d'y publier du contenu illégal aux yeux de la loi, sont considérés illégaux entres
						autres les contenus suivants : contenu à caractère raciste, contenu diffamatoire, contenu incitant à la haine,
						à la violence, contenu expliquant comment pirater (i.e. : à des fins néfastes ou non), contenu violant les droits
						d'auteur.<br/>

						À cette liste non exhaustive vient s'ajouter l'interdiction de publier du contenu à caractère sexuel.<br/>
						Cette liste étant non exhaustive, nous faisons appel à votre bon sens pour discerner ce que vous pouvez publier
						et / ou dire de ce que vous ne pouvez publier / dire.<br/>

						Les propos insultants, dégradants, agressifs ou tout comportement néfaste à une ambiance correcte sur l'ensemble
						du site sont interdits.<br/>

						Le thème de projet pour l'association n'est pas restreint, libre
						à vous de parler de projet de couture si ça vous chante,en espérant  trouver autant d'adeptes de la couture <br/>
						Les forums sont un espace de discussion important pour un site à caractère communautaire, surtout s'il est centré
						sur l'informatique, mais c'est aussi un espace d'entraide, par conséquent, n'hésitez pas à y poser vos questions si
						vous en avez, cependant, pensez à faire une recherche avant de poster une question, peut-être que la question a déjà été posée par
						un autre membre, et de plus, votre sujet devra avoir un titre clair et concis.<br/>

						
						Il est important de noter que pour votre confort, et le nôtre, le forum est surveillé par une équipe de modération
						bénévole, qui peut être ammenée à sanctionner tout membre enfreignant le règlement, ceci allant de l'avertissement
						à l'interdiction d'accéder au site.<br/>

						La messagerie privée est, comme son nom l'indique, privée. Cependant, vous acceptez l'idée que vous, ou votre / vos
						interlocuteur(s) puisse(nt), à tout moment, demander à l'équipe de modération du site de lire votre échange avec
						lui / eux en cas de problème.<br/>

						Vous reconnaissez que ce site est la propriété de son créateur, qui est, par conséquent libre de faire ce
						qu'il veut de celui-ci, tout en respectant le caractère privé des informations que vous, ou tout autre membre, lui donnez en vous
						inscrivant et en utilisant le site.<br/>

						Vous êtes donc propriétaire de votre compte et responsable de celui-ci (ainsi que des propos tenus avec), vous pouvez
						à tout moment demander sa suppression. Veuillez noter qu'à aucun moment, l'équipe du site ne vous demandera votre mot
						de passe.<br/>
						
					
						</p>
					</div>


























































					


 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
                    <?php
                        echo "avant le titre"."<br>";
                        $titre = 'Inscription 2/2';
                        /**********Vérification du titre...*************/
                       

                        if(isset($titre) && trim($titre) != '')
                        $titre = $titre.' : '.TITRESITE;
            
                        else
                                $titre = TITRESITE;
                                 /*
                                        Rien de bien particulier ici, à part le titre, le menu et la bannière.Elle contiendra 
                                        le code minimal HTML nécessaire de n'importe qu'elle site Internet.

                                Pour le titre (dans la balise <title> ), on vérifie simplement que la variable existe : 
                                si oui, on l'affiche.*/
            
                        /***********Fin vérification titre...************/
                        echo "après le titre"."<br>";
                     ?>

                     <title><?php echo $titre; ?></title>
                     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                     <meta name="language" content="fr" />
                     <link rel="stylesheet"  type="text/css" href="../style/style.css" />
             
                </head>
        <body>

                <div id="banner1">
                        <p>ASSOSSIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
            </div>
                <div class="menu">
                        <ul>
                        <li> <a href="../index.php">Accueil</a></li> 
                    </ul> 
            </div>

            <div id="banner2">
            </div>
 <h1>Inscription validée !</h1>
                        <p>Nous vous remercions de vous être inscrit sur notre site, votre inscription a été validée !<br/>
                        Vous pouvez vous connecter avec vos identifiants <a href="accueil.php">ici</a><br/>.
                        <?php// echo $sent; ?>
                         <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <div id="footer">

                        <p>Pied de page</p>

                </div>

 <?php echo "Après html";?>

<!--Test des erreurs et envoi-->
<?php
        echo "Le Test des erreurs et envoi";
                        if($_SESSION['erreurs'] == 0)
                        {
                                $insertion = "INSERT INTO membres VALUES(NULL, '".mysql_real_escape_string($pseudo)."',
                                '".md5($mdp)."', '".mysql_real_escape_string($mail)."',
                                ".time().",
                                '', '',
                                '', '',
                                '', '',
                                '', '',
                                ".time().", 0)";
                                
                                if(mysql_query($insertion))
                                        {
                                                if(inscription_mail($email, $pseudo, $mdp))
                                                $sent = 'Un mail de confirmation vous a été envoyé.';
                                                else 
                                                $sent = 'Un mail de confirmation devait être envoyé, mais son envoi a échoué, 
                                                vous êtes cependant bien inscrit.';
                                                vidersession();
                                                $_SESSION['inscrit'] = $pseudo;
                                                /*informe qu'il s'est déjà inscrit s'il actualise, si son navigateur
                                                bugue avant l'affichage de la page et qu'il recharge la page, etc.*/
?>
                                <h1>Inscription validée !</h1>
                                <p>Nous vous remercions de vous être inscrit sur notre site, votre inscription a été validée !<br/>
                                        Vous pouvez vous connecter avec vos identifiants <a href="connexion.php">ici</a>.
                                        <?php echo $sent; ?>
                                </p>
<?php
                                        }
                                
                                else
                                {   
                                /*
                                        "stripos" est un fonction qui recherche la première occurrence d'une chaîne 
                                        dans une autre et retourne sa position (qui peut valoir 0 si le premier caractère 
                                        de l'occurrence est le premier de la chaîne),
                                        "stripos" est insensible à la casse contrairement à "strpos".

                                        Le bute est de signalé l'utilisateur qu'un pseudo est UNIQUE est qu'il doit le modifier 
                                        pareil pour l'email (un email par pseudo).
                                */
                                        if(stripos(mysql_error(), $_SESSION['form_pseudo']) !== FALSE) // recherche du pseudo
                                        { 
                                                unset($_SESSION['form_pseudo']);
                                                $_SESSION['pseudo_info'] = 
                                                '<span class="erreur">Le pseudo '
                                                .htmlspecialchars($pseudo, ENT_QUOTES).
                                                ' est déjà pris, choisissez-en un autre.</span><br/>';
                                                $_SESSION['erreurs']++;
                                        }
                                        
                                        if(stripos(mysql_error(), $_SESSION['form_mail']) !== FALSE) //recherche du mail
                                        {
                                                unset($_SESSION['form_mail']);
                                                unset($_SESSION['form_mail_verif']);
                                                $_SESSION['mail_info'] = 
                                                '<span class="erreur">Le mail '.htmlspecialchars($mail, ENT_QUOTES).' est déjà pris,
                                                <a href="../contact.php">contactez-nous</a> si vous pensez à une erreur.</span><br/>';
                                                $_SESSION['mail_verif_info'] = str_replace('mail', 'mail de vérification',
                                                $_SESSION['mail_info']);
                                                $_SESSION['erreurs']++;
                                                $_SESSION['erreurs']++;
                                        }
                                        
                                        if($_SESSION['erreurs'] == 0)
                                        {
                                                $sqlbug = true; //plantage SQL.
                                                $_SESSION['erreurs']++;
                                        }
                                }
                        }
                                



//Envoie d'email 
/*function inscription_mail($email, $pseudo, $passe)
        {
                $to = $email;
                $subject = 'Inscription sur '.TITRESITE.' - '.$pseudo;


                //On définit le message
                $message = '<html>
                                <head>
                                        <title></title>
                                </head>
                                        
                                <body>
                                        <div>Bienvenue sur '.TITRESITE.' !<br/>
                                        Vous avez complété une inscription avec le pseudo
                                        '.htmlspecialchars($pseudo, ENT_QUOTES).' à l\'instant.<br/>
                                        Votre mot de passe est : '.htmlspecialchars($passe, ENT_QUOTES).'.<br/>
                                        Veillez à le garder secret et à ne pas l\'oublier.<br/><br/>
                                                
                                                
                                        '.TITRESITE.'
                                </body>
                             </html>';



        // Le message est restreint : en effet, on ne peut envoyer que des textes contenant 70 caractères par ligne, chaque ligne étant séparée par un .
        //Il y a de plus une histoire avec les . dans le message...
        //Bref, avec la fonction "mail" , on ne peut rien faire
        //mais la fonction "mail" peut formater des mails en HTML, c'est ce qui va nous servir par la suite ; avec cette fonction, vous pourrez même faire de la mise //en forme, envoyer des pièces jointes (images, etc.), vous donnerez ainsi des rendus agréables à lire.


        //headers principaux.
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";





                //L'envoie du mail

                $email = mail($to, $subject, $message, $headers); //marche

                if($email) return true;
                return false;
        }

                                if(mysqli_query($insertion))
                                {
                                        if(inscription_mail($email, $pseudo, $mdp)){ $sent = 'Un mail de confirmation vous a été envoyé.';}

                                        else {$sent = 'Un mail de confirmation devait être envoyé, mais son envoi a échoué, vous êtes cependant bien inscrit.';}
                                                vidersession();
                                                $_SESSION['inscrit'] = $pseudo;
                                }
                                 /*
                                        informe qu'il s'est déjà inscrit s'il actualise, si son navigateur
                                        bugue avant l'affichage de la page et qu'il recharge la page, etc.
                                */
?>











































        $connexionbdd = mysql_connect(SERVEUR, LOGIN, MDP);
                                if (!$connexion)
                                        {
                                                echo "LA CONNEXION AU SERVEUR MYSQL A ECHOUE\n";
                                                exit;
                                        }
                                mysql_select_db(BDD); 
                                print ("Connexion BDD reussie puis"); 
                                echo "<br/>";
                                //On parcours la bdd pour chercher l'existence d'un mdp et identifiant saissis par l'internaute
                                //et on range le résultat dans le tableau $data
                                $sql = 'SELECT count(*) FROM membres WHERE membre_id="'.mysql_escape_string($_POST['pseudo']).'"
                                AND membre_mdp="'.mysql_escape_string(membre_mdp($_POST['mdp1'])).'"';
                                $req = mysql_query($sql) or die('Erreur SQL !<br />'.$sql.'<br />'.mysql_error());
                                 $data = mysql_fetch_array($req);
                                 mysql_free_result($req);mysql_close();
                                 //Si on obtient une réponse, alors l'utilisateur est un membre 
                                 //on ouvre une session pour cet utilisateur et on le connecte à l'espace membre
                                 if ($data[0] == 1)
                                 {
                                        session_starts();
                                        $_SESSION['pseudo']= $_POST['pseudo'];
                                        header('Location: espace_membre.php');
                                        exit();
                                 }
                                 //Si le visiteur a saisi un mauvais identifiant ou mdp, on ne trouve aucune réponse
                                 elseif ($data[0] == 0) 
                                 {
                                        echo "Indentifiant ou mdp non reconnu!";
                                        echo "<br/><a href=\"accueil.php\">Accueil</a>";
                                        exit();
                                 }
                                 // Sinon un problème avec la bdd
                                 else
                                 {
                                        echo "Plusieurs membres ont<br> les memes identifiants!";
                                        echo "<br /><a href=\"accueil.php\">Accueil</a>";
                                        exit();
                                 }
                                  echo " Fin du 1er";
                        }
                        
                                 else
                                 {
                                        echo"Erreur de saisie <br /> un des champs est vide!";
                                        echo "<br><a href=\"accueil.php\">Accueil</a>";
                                        exit();
                                 }
                }
                }