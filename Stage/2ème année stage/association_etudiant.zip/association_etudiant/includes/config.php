<?php
    /*

    Page config.php

    Deux define et la variable de queries.



    Variable de configuration ""rootpath"" dans un fichier de configuration 
    et l'inclure partout où j'en ai besoin, pour n'avoir qu'une et une seule modification de NDD à faire.
    comme chemin absolue
    */
    define('ROOTPATH', __DIR__ );/* si vous êtes en local, il faudra peut-être modifier ce ""commentaire"" 'http://'.$_SERVER['HTTP_HOST'] pour qu'il pointe sur votre dossier de test*/
    define('TITRESITE', "Site d'association des étudiants", true); 


    /*
        REMARQUE les 2 defines sont des constantes donc lors de leur utilisation ne faite que 
        des ""include_onces"".
    */
   

    
?>