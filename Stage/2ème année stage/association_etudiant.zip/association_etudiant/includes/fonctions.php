<?php
	/*

		Page fonctions.php

		    si le membre a un pseudo, on compare les mots de passe en session et venant de la bdd, 
		    et si tout roule, on valide la session du membre ; sinon, on inclut information.php et on affiche une erreur.

		    Si le membre n'a pas de session, on va dans le else, on vérifie donc s'il a des cookies et s'ils sont valides,
		    la procédure ressemble assez à celle des sessions, sauf que si le cookie id est incorrect, on génère une autre erreur.


		Liste des fonctions :
		--------------------------
		sqlquery($requete,$number)
		actualiser_session()
		vider_cookie()


		checkpseudo()
		checkmdp()
		checkmdpS()
		checkmail()
		--------------------------

	
		Liste des informations/erreurs :
		--------------------------
		Mot de passe de session incorret
		Mot de passe de cookie incorrectc
		L'id de cookie est incorrect
		--------------------------
	*/
		


		function sqlquery($requete, $number)
		{
			$query = mysqli::query($requete) or exit('Erreur SQL : '.mysql::error().' Ligne : '. __LINE__ .'.'); //requête
			queries();
		
			
				/*Deux cas possibles ici :
				Soit on sait qu'on a qu'une seule entrée qui sera
				retournée par SQL, donc on met $number à 1
				Soit on ne sait pas combien seront retournées,
				on met alors $number à 2.*/
			
		
			if($number == 1)
			{
				$query1 = mysqli_fetch_assoc($query);
				mysql_free_result($query);
				mysql_free_result($query) ;//libère le contenu de $query, je
				//le fais par principe, mais c'est pas indispensable.
				return $query1;
			}
		
			else if($number == 2)
			{
				while($query1 = mysqli_fetch_assoc($query))
				{
					$query2[] = $query1;
					/*On met $query1 qui est un array dans $query2 qui
					est un array. Ca fait un array d'arrays*/
				}
				mysql_free_result($query);
				return $query2;
			}
		
				else //Erreur
			{
				exit('Argument de sqlquery non renseigné ou incorrect.');
			}
		}
		

		function queries($num = 1)
		{
			global $queries;
			$queries = $queries + intval($num);
		}


		function vider_cookie()
		{
			foreach($_COOKIE as $cle => $element)
			{
				setcookie($cle, '', time()-3600);
			}
		}


	function actualiser_session()
		{
		if(isset($_SESSION['membre_id']) && intval($_SESSION['membre_id']) != 0) //Vérification id
			{
		        //utilisation de la fonction sqlquery, on sait qu'on aura qu'un résultat car l'id d'un membre est unique.
		        //"" intval()"", une fonction très intéressante qui retourne la valeur numérique entière d'une variable ; 
		        //si la variable est une chaîne commençant par une lettre, on aura un 0.

				$retour = sqlquery("SELECT membre_id, membre_pseudo, membre_mdp FROM membres WHERE membre_id = ".intval($_SESSION['membre_id']), 1);
				
				//Si la requête a un résultat (id est : si l'id existe dans la table membres)
				if(isset($retour['membre_pseudo']) && $retour['membre_pseudo'] != '')
				{
					if($_SESSION['membre_mdp'] != $retour['membre_mdp'])
					{
						
						$informations = Array(/*Mot de passe de session incorrect*/
											true,
											'Session invalide',
											'Le mot de passe de votre session est incorrect, vous devez vous reconnecter.',
											'',
											'membres/connexion.php',
											3
											);
						require_once('../information.php');
						vider_cookie();
						session_destroy();
						exit();
					}
					
					else
					{
						//Validation de la session.
							$_SESSION['membre'] = $retour['membre_id'];
							$_SESSION['membre'] = $retour['membre_pseudo'];
							$_SESSION['membre'] = $retour['membre_mdp'];
					}
				}
			}
		
			else //On vérifie les cookies et sinon pas de session
			{
				if(isset($_COOKIE['membre_id']) && isset($_COOKIE['membre_mdp'])) //S'il en manque un, pas de session.
				{
					if(intval($_COOKIE['membre_id']) != 0)
					{
						//idem qu'avec les $_SESSION
						$retour = sqlquery("SELECT membre_id, membre_pseudo, membre_mdp FROM membres WHERE membre_id = ".intval($_COOKIE['membre_id']), 1);
						
						if(isset($retour['membre_pseudo']) && $retour['membre_pseudo'] != '')
						{
							if($_COOKIE['membre_mdp'] != $retour['membre_mdp'])
							{
								
								$informations = Array(/*Mot de passe de cookie incorrect*/
													true,
													'Mot de passe cookie erroné',
													'Le mot de passe conservé sur votre cookie est incorrect vous devez vous reconnecter.',
													'',
													'membres/connexion.php',
													3
													);
								require_once('../information.php');
								vider_cookie();
								session_destroy();
								exit();
							}
							
							else
							{
								
								$_SESSION['membre_id'] = $retour['membre_id'];
								$_SESSION['membre_pseudo'] = $retour['membre_pseudo'];
								$_SESSION['membre_mdp'] = $retour['membre_mdp'];
							}
						}
					}
					
					else //cookie invalide, erreur plus suppression des cookies.
						{
							$informations = Array(
							/*L'id de cookie est incorrect*/
							true,
							'Cookie invalide',
							'Le cookie conservant votre id est corrompu, il va donc être détruit vous devez vous reconnecter.',
							'',
							'membres/connexion.php',
							3
								);
							require_once('../information.php');
							vider_cookie();
							session_destroy();
							exit();
						}
				}
				
				else
					{
						//Fonction de suppression de toutes les variables de cookie.
						if(isset($_SESSION['membre_id'])) unset($_SESSION['membre_id']);
						vider_cookie();
					}
			}
		}


 		/* 
            ATTENTION!! On ne détruit pas la session avec un 'session_destroy()' 
            on la vide sinon on ne poura pas créer un '$_SESSION['inscrit]' 
            lorsque l'incripstion est incorrect et d'afficher les erreurs commises '
        */
        function vidersession()
	        {
	                foreach($_SESSION as $cle => $element)
	                {
	                        unset($_SESSION[$cle]);
	                }
	        }





        /*vérifier dans l'ordre si le pseudo est vide, ensuite, 
        s'il est trop court ou trop long, et enfin s'il est pris, etc...*/
        /*Vérifie l'émail et s'il est déjà pris */

        function checkpseudo($pseudo)
	        {
	        	require_once("BDD.php");//Connextion BDD


	            			//DSN de connexion
				    		$dsn = "mysql:dbname=".DBNAME.";host=".DBHOST;

				    		//option de PDO.
				    		$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

				    		//Connexion à la base de données
					    	try
					    	{	
					    		//On instancie PDO
					    		
					        	$bdd = new PDO($dsn, DBUSER, DBPASSWD, $pdo_options);
				



					        	//On s'assure d'envoyer les données en UTF8
					        	$bdd->exec("SET NAMES utf8");

				

			        	

					    	}
					   	 	catch(PDOException $e)
					    		{
					        		die("Erreur de connexion à la BDD: ".$e->getMessage() );
					    		}


				

	        	//Trop courts ou trop long
	                if($pseudo == '') return 'empty';
	                else if(strlen($pseudo) < 5) return 'tooshort';
	                else if(strlen($pseudo) > 32) return 'toolong';
	               
	               
	                
	                else
	                { 		


							$stmt = $bdd->prepare("SELECT * FROM membres WHERE membre_pseudo=?");

	                        $stmt->execute([$pseudo]);

   
	                        $user = $stmt->fetch();

	                        if ($user
	                        ) return 'exists';
	                        else return 'ok';
					}
   		
        	}	


		function checkmail($email)
	        {
 				require_once("BDD.php");//Connextion BDD
 				$dsn = "mysql:dbname=".DBNAME.";host=".DBHOST;

	    		//option de PDO.
	    		$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

	    			$point = ".";
	            	$arob = "@";
	                $point = strpos($email,$point);
					$arob = strpos($email, $arob);

	    		//Connexion à la base de données
		    	try
		    		{	
						//On instancie PDO
								    		
						$bdd = new PDO($dsn, DBUSER, DBPASSWD, $pdo_options);
							



						//On s'assure d'envoyer les données en UTF8
						$bdd->exec("SET NAMES utf8");

					}
					catch(PDOException $e)
					{
						die("Erreur de connexion à la BDD: ".$e->getMessage() );
					}

				

 				 if($email == '') return 'empty';
	            	
					if ($point ===false) return 'isnt'; 
					else if ($arob ===false) return 'isnt';
					
	                else{
	                	
	                        $stmt = $bdd->prepare("SELECT * FROM membres WHERE membre_mail=?");
	                        $stmt->execute([$email]);
	                        
	                        $user = $stmt->fetch();
	                        
	                        if ($user) return 'exists';
	                        else return 'ok';
	                }

	        }
	        


        /*vérifier si le mot de passe entré est ni trop long ni trop court,
         s'il contient au moins un chiffre et au moins une majuscule, etc... */

        function checkmdp($mdp1)
	        {
	                if($mdp1 == '') return 'empty';
	                else if(strlen($mdp1) < 8) return 'tooshort';
	                else if(strlen($mdp1) > 50) return 'toolong';
	                
	                else
	                {
	                        if(!preg_match('#[0-9]{1,}#', $mdp1)) return 'nofigure';
	                        else if(!preg_match('#[A-Z]{1,}#', $mdp1)) return 'noupcap';
	                        else return 'ok';
	                }
	        }




		/*Mot de passe de vérification en tapant le même mdp crée. */
        function checkmdpS($mdp2, $mdp1)
	        {
	                if($mdp1 != $mdp2 && $mdp1 == '' && $mdp2 == '') return 'different';
	                else return 'ok';
	        }





?>