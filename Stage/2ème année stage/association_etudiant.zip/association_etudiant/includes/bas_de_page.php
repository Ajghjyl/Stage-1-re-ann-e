<?php 
/*
Pied de page
*/
 ?>

 	                <div id="footer">
                        <p>Pied de page</p>
        
                </div>
        </body>
 </html>





