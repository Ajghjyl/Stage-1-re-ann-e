<?php
        /*

        Page index.php

        Affichage de profil.

        ADMIN
        */

        session_start();

	if (!$_SESSION['admin']) {
		header("Location: ../membres/connexion.php");
	}
        header('Content-type: text/html; charset=utf-8');
        include('../includes/config.php');

        /********Actualisation de la session...**********/
        //Les fonctions

        include('../includes/fonctions.php');

        
       




        /********Fin actualisation de session...**********/

  
?>


 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
              
             <title>Admin</title>
             <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
             <meta name="language" content="fr" />
             <link rel="stylesheet"  type="text/css" href="../style/style.css" />
             
        </head>

<!---->
<!---->

       <body>
                    <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>
    <div class="menu">
                          <ul>
                               <!-- <li> <a href="home.php">Mon compte</a> </li> -->
                                <li> <a href="deconnexion.php">Se déconnecter</a> </li>
                            
                          </ul>
     </div>
                      
        <div id="banner2">
                                
        </div>

                <a href="membres.php">Afficher les membres de l'adhésion</a><br>
				<a href="publishArticle.php">Ajouter un nouveau article</a><br>
                <a href="article.php">Liste des articles</a><br>

                                   <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>              
                     
                                
          <?php
                include('../includes/bas_de_page.php');
          ?>



