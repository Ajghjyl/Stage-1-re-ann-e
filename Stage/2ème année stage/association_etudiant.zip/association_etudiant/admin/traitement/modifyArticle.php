<?php 
	session_start();

	header('Content-type: text/html; charset=utf-8');
    include_once('../../includes/config.php');
    require_once("../../includes/BDD.php");

  	if (isset($_GET['id']) AND !empty($_GET['id'])) 
    {
    	$getId = $_GET['id'];
    	$sql ='SELECT * FROM article WHERE id= ?';
    	$query = $bdd->prepare($sql);

    	//On exécute la requête
        if(!$query->execute(array($getId)) )
        {
            die("Problème avec l'exécusion");
        }

        if ($query->rowCount() > 0) 
        {
        	$articleInfos = $query->fetch();
        	$titre = $articleInfos['title'];
        	$contenu = str_replace('<br/>', '', $articleInfos['content']);
        	if (isset($_POST['valider'])) 
        	{
        		$titreSaisi = htmlspecialchars($_POST['title']);
        		$contenuSaisi = nl2br(htmlentities($_POST['content']));

        		$sql = 'UPDATE article SET title =? AND content= ? WHERE id = ?';
        		$updateArticle = $bdd->prepare($sql);
        		if( !$updateArticle->execute( array($titreSaisi, $contenuSaisi) ) )
        		{
        			die("Problème avec l'exécusion");
        		}
 
        		$_SESSION['erreurLogin'] = "Article modifier avec succès.";
	        	header("Location: admin/article.php");
        	}
        }
        else
        {
        	$_SESSION['erreurLogin'] = "Aucun article trouvé.";
	        header("Location: admin/article.php");
        }
    }
    else
    {
    	header("Location: ../article.php");
    }
  
 ?>

  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
 <html>
 <head>
        <title>Modifier article</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="language" content="fr" />
        <link rel="stylesheet"  type="text/css" href="../../style/style.css" />
     
 </head>
 <body>

     <div id="banner1">
             <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
     </div>
            
        
                            <div class="menu">
                          <ul>
                                <li> <a href="../index.php">Mon compte</a> </li> 
                                <li> <a href="deconnexion.php">Se déconnecter</a> </li>
                                <li> <a href="../article.php">Retour</a> </li>        
                          </ul>
                         </div>
                
                      
        <div id="banner2">
                             
        </div>
    <br><br><br><br><br><br>
	
	 <body>
	 	<form>
	 		<input type="text" name="title" value="<?= $titre; ?>">
	 		<br>
	 		<textarea name="content"><?= $contenu; ?></textarea>
	 		<input type="submit" name="valider">
	 	</form>
	            
	            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	 </body>

	 <?php 
	 	include("../../includes/bas_de_page.php");
	 ?>
 </html>
