<?php
	/*
 
	Page de validation_connexion.php

	Les conditions de validations du site.

	PARTIE ADMIN

	Liste des informations/erreurs :
	--------------------------
	
	--------------------------
	*/

	include('../../includes/config.php');

	/********Actualisation de la session...**********/

	include('../../includes/fonctions.php');
	
	

/********Fin actualisation de session...**********/
session_start();
	//On Vérifie que le visiteur a bien envoyer le formulaire.
	
		
		if (!empty($_POST))  
		{ 
				if (!empty($_POST['pseudo']) AND !empty($_POST['mdp1'])) 
				{
					// Le formulaire a été envoyé
			        //On vérifie que TOUS les champs requis sont remplis
			        // On appelle le mdp et pseudo propre à l'administrateur
						
						$pseudo_par_defaut = "admin";
						$mdp_par_defaut = "dpkzamofjzol:zdmk,s:gn:mz!péize";

						$pseudo_saisi = htmlspecialchars($_POST['pseudo']);
						$mdp_saisi = htmlspecialchars($_POST['mdp1']);
						

						if ($pseudo_saisi == $pseudo_par_defaut AND $mdp_saisi == $mdp_par_defaut) 	
							   
							{
								

								$_SESSION['admin'] = $_SESSION['user'];
								
								

								header('Location: ../index.php');
							}
							else
	            {
	                                          
	                $_SESSION['erreurLogin'] = "Le pseudo et/ou le mot de passe est incorrect.";
	            		header("Location: ../connexion.php");
	            }
	               
	                                        
	        }
	        else
	        {     
	           $_SESSION['erreurLogin'] = "Le formulaire est incomplet.";
	           header("Location: ../connexion.php");
	        } 

            
	                            
	   }
	   else
	   {      
	   		
	      header("Location: ../connexion.php");                           
	                                                 
	    }   

?>
