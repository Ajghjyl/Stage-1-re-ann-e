<?php  
	session_start();
	require_once("../../includes/BDD.php");
	include('../../includes/config.php');
		if (!empty($_POST))  
			{ 
					if (!empty($_POST['title']) AND !empty($_POST['content'])) 
					{
							// Le formulaire a été envoyé
				      		//On vérifie que TOUS les champs requis sont remplis
				     
							$titre = htmlspecialchars($_POST['title']);
							$contenu = nl2br(htmlentities($_POST['content']));
							

							$sql = "INSERT INTO article(title, content) 
							VALUES(?, ?)";
		               		$query= $bdd->prepare($sql);

		               	 	//On exécute la requête
                            if(!$query->execute(array($titre, $contenu)))
                            {
                            	die("Problème avec l'exécusion");
                            }
                        	$_SESSION['erreurLogin'] = "Article envoyé.";
                                

		                header("Location: ../publishArticle.php");                     
			        }
			        else
			        {     
			           $_SESSION['erreurLogin'] = "Le formulaire est incomplet.";
			           header("Location: index.php");
			        }                            
		   }
		   else
		   {      
		   		
		      header("Location: ../connexion.php");                           
		                                                 
		    } 
?>