<?php 
	session_start();

	header('Content-type: text/html; charset=utf-8');
    include_once('../../includes/config.php');
    require_once("../../includes/BDD.php");

    if (isset($_GET['id']) AND !empty($_GET['id'])) 
    {
    	$getId = $_GET['id'];
    	$sql ='SELECT * FROM article WHERE id= ?';
    	$query = $bdd->prepare($sql);

    	//On exécute la requête
        if(!$query->execute(array($getId)) )
        {
            die("Problème avec l'exécusion");
        }

        if ($query->rowCount() > 0) 
        {
        	$sql ='DELETE FROM article WHERE id= ?';
        	$deleteArticle = $bdd->prepare($sql);
        	if(!$deleteArticle->execute(array($getId)) )
        	{
            die("Problème avec l'exécusion");
        	}

        	$_SESSION['erreurLogin'] = "Article supprimé avec succès.";
	        header("Location: ../article.php");

        }
        else
        {
        	$_SESSION['erreurLogin'] = "Aucun article trouvé.";
	        header("Location: ../article.php");
        }
    }
    else
    {
    	header("Location: ../article.php");
    }
 ?>