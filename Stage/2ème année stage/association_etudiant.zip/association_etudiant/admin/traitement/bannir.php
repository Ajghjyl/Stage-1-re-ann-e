<?php 
    require_once("../includes/BDD.php");
    $bdd = new PDO($dsn, DBUSER, DBPASSWD, $pdo_options);
    


    session_start();
        if (!empty($_GET))  
        { 
               if (isset($_GET['id']) && !empty($_GET['id']))
               {    
                     $id = $_GET['id'];
                     $sql =('SELECT * FROM membres WHERE membre_id = ?');
                     $query= $bdd->prepare($sql);
                     $query->execute(array($id));

                     //Si c'est pas vide
                     if ($query->rowCount() > 0) 
                     {
                         //Système qui va bannir les utilisateurs
                        $bannir_user = $bdd->prepare('DELETE FROM membres WHERE membre_id = ?');
                        $bannir_user->execute(array($id));

                        $_SESSION['erreurLogin'] = "Un utilisateur a été banni.";
                        header('Location: ../membres.php');
                     }
                     else
                     {
                        $_SESSION['erreurLogin'] = "Aucun membre n'a été trouvé.";
                        header("Location: ../membres.php");
                     }
                }
        }
         else
              {
                 
                
                    header("Location:  ../membres.php");
                    exit;
          
                
              }
        
?>