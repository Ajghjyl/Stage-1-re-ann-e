<?php 
    session_start();
    
    header('Content-type: text/html; charset=utf-8');
    require_once __DIR__ . "/../includes/config.php";;
    require_once("../includes/BDD.php");

    $sql = $bdd->query('SELECT *FROM article');
?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
 <html>
 <head>
        <title>Afficher tous les articles</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="language" content="fr" />
        <link rel="stylesheet"  type="text/css" href="../style/style.css" />
     
 </head>
 <body>

     <div id="banner1">
             <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
     </div>
            
        
                            <div class="menu">
                          <ul>
                                <li> <a href="index.php">Mon compte</a> </li> 
                                <li> <a href="traitement/deconnexion.php">Se déconnecter</a> </li>        
                          </ul>
                         </div>
                
                      
        <div id="banner2">
                             
        </div>
    <br><br><br><br><br><br>
 <?php 
    
    while($article = $sql->fetch()){
  ?>
    <div  id="banner1" class ="article" style="border: 9px solid color: #99D9EA">
        <h1><?= $article['title'];?></h1>
        <br>
        <p><?= $article['content'];?></p><br>
        <p>Crée le: <?= $article['created_at'];?></p><br>

        <a href="traitement/deleteArticle.php?id=<?= $article['id'];?>"><button style="color:white; background-color: red;">Supprimer</button> 
        </a>
        <a href="traitement/modifyArticle.php?id=<?= $article['id'];?>"><button style="color:white; background-color: orange;">Modifier</button> 
        </a>
        
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php 
    }
    if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       }
 ?>
 </body>
 </html>