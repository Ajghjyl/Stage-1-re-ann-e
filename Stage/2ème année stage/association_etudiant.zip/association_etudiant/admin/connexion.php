<?php
    /*

    Page connexion.php

    Permet de se connecter.

    ADMIN

    */

    
    header('Content-type: text/html; charset=utf-8');

    include_once('../includes/config.php');
      
        /********Actualisation de la session...**********/
        //Les fonctions
        include('../includes/fonctions.php');

       session_start();

        if (!isset($_SESSION["user"]) or isset($_SESSION["admin"])) 
        {
            header("Location:  ../membres/profil.php");
            exit;
          
        }
       
       
        /********Fin actualisation de session...**********/

 
    $titre = 'Accueil';


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
                <?php
                    /**********Vérification du titre...*************/
                   $titre = "Espace de connexion admin";

                    if(isset($titre) && trim($titre) != '')
                    $titre = $titre.' : '.TITRESITE;
        
                    else
                            $titre = TITRESITE;
                             /*
                                    Rien de bien particulier ici, à part le titre, le menu et la bannière.Elle contiendra 
                                    le code minimal HTML nécessaire de n'importe qu'elle site Internet.

                                    Pour le titre (dans la balise <title> ), on vérifie simplement que la variable existe : 
                                    si oui, on l'affiche.*/
        
                    /***********Fin vérification titre...************/
                 ?>

                 <title><?php echo $titre; ?></title>
                 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                 <meta name="language" content="fr" />
                 <link rel="stylesheet"  type="text/css" href="../style/style.css" />
                    
            </head>
        <body>

            <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
            </div>
                <div class="menu">
                   
            </div>

                            <div id="banner2">
                            </div>
            

                <form action="traitement/validation_connexion.php" method="post" name="Connexion">
                    <fieldset>
                        <legend>Connexion</legend>

                        <label for="pseudo" class="float">Pseudo :</label> 
                        <input type="text" name="pseudo" id="pseudo" size="30" /> 
                        <br>

                        <label for="mdp1" class="float">Mot de passe :</label>
                        <input type="password" name="mdp1" id="mdp1" size="30" />
                        <br/>      
                    </fieldset>
                    <div class="center"><input type="submit" value="valider" /></div>
                </form>
 <?php 
                       
                       if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       }
                       
 ?>
                        
                        
                       
      <!--bas-->
     
      <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

      

                <div id="footer">
                        <p>Pied de page</p>
                </div>  
         </body>
 </html>