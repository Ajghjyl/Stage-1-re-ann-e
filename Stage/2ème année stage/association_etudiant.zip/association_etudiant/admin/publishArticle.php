<?php 
    /*

           Page article.php

           


    */

           ;
            session_start();
            include('../includes/config.php');
           
       
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <meta charset="utf-8/">

    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >

            <head>
              
            
            

                <?php
                    /**********Vérification du titre...*************/
                   

                    if(isset($titre) && trim($titre) != '')
                    $titre = $titre.' : '.TITRESITE;
        
                    else
                            $titre = TITRESITE;
                             /*
                                   

                            Pour le titre (dans la balise <title> ), on vérifie simplement que la variable existe : 
                            si oui, on l'affiche.*/
        
                    /***********Fin vérification titre...************/
                 ?>

             <title><?php echo $titre; ?></title>
             <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
             <meta name="language" content="fr" />
             <link rel="stylesheet"  type="text/css" href="../style/style.css" />
             
        </head>

<!---->
<!---->

       <body>
                    <div id="banner1">
                        <p>ASSOCIATION DES ETUDIANTS DU LYCEE MATHIAS</p>
                    </div>
            
           

              
                          
                      
                
                      <div class="menu">
                          <ul>
                                <li> <a href="/profil.php">Mon compte</a> </li> 
                                <li> <a href="/deconnexion.php">Se déconnecter</a> </li>
                                
                            
                          </ul>
           
                    </div>
                       
                
                      
        <div id="banner2">
                                
        </div>


            <!--Le corps de pages-->
          <h1>Création d'article</h1>
          

            <form method="POST" action="traitement/publishArticleAction.php">
                <input type="text" name="title">
                <br>
                <textarea name="content"></textarea>
                <br>
                <input type="submit" name="envoi">
            </form>
<?php 
    if (isset($_SESSION['erreurLogin'])) 
     {
        echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
        unset($_SESSION['erreurLogin']);
      }
?>

        <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br><br> <br> <br> <br> <br> <br><br><br> <br> <br> <br> <br> <br><br>

</html>

 <?php

                include('../includes/bas_de_page.php');
?>