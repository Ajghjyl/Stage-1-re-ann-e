<?php
/*

Page deconnexion.php

Permet de se déconnecter du site.

*/

session_start();
       if (!$_SESSION['admin']) {
              header("Location: connexion.php");
       }

unset($_SESSION["admin"]); // PAS DE DESTROY OU VOUS RISQUEZ DE DETRUIRE TOUTE LES SESSIONS ON VEUT JUSTE RETIRER LE CONTENU D4UNE SESSION SPECIFIQUE

header("Location: connexion.php")


?>