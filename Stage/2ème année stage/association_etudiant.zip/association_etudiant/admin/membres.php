<?php 

       session_start();
       if (!$_SESSION['admin']) {
              header("Location: connexion.php");
       }


       header('Content-type: text/html; charset=utf-8');

       //On appelle la BDD
       require_once("../includes/BDD.php");
       $bdd = new PDO($dsn, DBUSER, DBPASSWD, $pdo_options);

       // On appelle tous le membres
       $sql = $bdd->query('SELECT *FROM membres');


       include("../includes/haut_de_page.php");
?>

   


       
              <?php 
              while ($user = $sql->fetch())
                     //On crée une boucle qui parcourt la table membre
              { 
                    ?>
              <form action="gestion.php" method="get" name="gestion">
              </form>
                            <table>
                                   <caption>Membre de l'adhésion</caption>
                                          <thead><!--Important-->
                                                 <tr>
                                                        <th>Pseudo</th>
                                                        <th>ID</th>
                                                        <th>Rôle</th> 
                                                 </tr>
                                          </thead> 
                                               <tr>
                                                        
                                                 <th><?= $user['membre_pseudo']?></th>
                                                 <th><?= $user['membre_id']?></th>
                                                 <th><?= $user['membre_type']?></th> 
                                                 <th><a href="traitement/bannir.php?id=<?= $user['membre_id']; ?>" style ="color:red; text-decoration: none;">Bannir</a></th>
                                                        
                                               </tr>
                                              
                             </table> 
             

             <?php 
              }
if (isset($_SESSION['erreurLogin'])) 
                       {
                            echo '<div class="alert alert-danger" role="alert"><strong>'. $_SESSION['erreurLogin'] . '</strong></div>';
                            unset($_SESSION['erreurLogin']);
                       }
                       
              ?>
      
               
       
                                                 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>       

</body>

<?php 
       include("../includes/bas_de_page.php");
?>